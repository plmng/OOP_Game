﻿namespace Empires.Contracts
{

    public interface IBuilding : IUnitProducer, IResourceProducer, IUpdateable
    {
    }
}
