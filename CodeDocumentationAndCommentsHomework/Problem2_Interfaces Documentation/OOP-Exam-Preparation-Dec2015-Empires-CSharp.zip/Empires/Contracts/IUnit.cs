﻿namespace Empires.Contracts
{
    public interface IUnit : IAttacker, IDestroyable
    {
    }
}
