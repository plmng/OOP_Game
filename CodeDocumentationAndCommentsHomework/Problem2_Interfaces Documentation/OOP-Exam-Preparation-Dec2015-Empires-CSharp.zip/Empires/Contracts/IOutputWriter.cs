﻿namespace Empires.Contracts
{
    public interface IOutputWriter
    {
        void Print(string message);
    }
}
