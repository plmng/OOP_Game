﻿namespace CohesionAndCoupling
{
    public interface IPoint3D : IPoint2D
    {
        double Z { get; }
    }
}
