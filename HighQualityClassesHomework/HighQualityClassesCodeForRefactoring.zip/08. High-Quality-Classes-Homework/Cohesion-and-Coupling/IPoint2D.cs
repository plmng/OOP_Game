﻿namespace CohesionAndCoupling
{
    public interface IPoint2D
    {
        double X { get; }

        double Y { get; }
    }
}
