﻿namespace Logger.Layouts
{
    using Core;
    using Core.Interfaces;

    public class XmlLayout : ILayout
    {
        public string GetFormatedMessage(LoggerMessage msg)
        {
            string formatedMsg = string.Format("<log>\n    <date>{0}</date>\n    <level>{1}</level>\n    <message>{2}</message>\n</log>", msg.Date, msg.ReportLevel, msg.Message);
            return formatedMsg;
        }
    }
}
